<?php
namespace App\Http\Controllers;

class SaleController extends Controller
{
    public function index()
    {
        return view('sales.index');
    }
}
