<!DOCTYPE html>
<html>

<head>
    <title>Beauty & Health</title>
</head>

<body>
    <h1>Daftar Produk - Kecantikan & Kesehatan</h1>
</body>

</html>
<?php /**PATH C:\laragon\www\Pemrograman-Web-Lanjut\Minggu-2\PWL-POS\resources\views/products/beauty-health.blade.php ENDPATH**/ ?>