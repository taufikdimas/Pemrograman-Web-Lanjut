<h1>User Profile</h1>
<p>User ID: <?php echo e($id); ?></p>
<p>User Name: <?php echo e($name); ?></p>
<?php /**PATH C:\laragon\www\Pemrograman-Web-Lanjut\Minggu-2\PWL-POS\resources\views/user/profile.blade.php ENDPATH**/ ?>