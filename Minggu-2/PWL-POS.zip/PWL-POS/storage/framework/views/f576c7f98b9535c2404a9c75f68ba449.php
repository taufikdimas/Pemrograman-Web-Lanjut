<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Transaction</title>
</head>

<body>
    <h1>Point of Sales - Halaman Transaksi</h1>
</body>

</html>
<?php /**PATH C:\laragon\www\Pemrograman-Web-Lanjut\Minggu-2\PWL-POS\resources\views/sales/index.blade.php ENDPATH**/ ?>