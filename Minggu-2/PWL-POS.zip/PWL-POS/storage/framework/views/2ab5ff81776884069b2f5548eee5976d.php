<!DOCTYPE html>
<html>

<head>
    <title>Food & Beverage</title>
</head>

<body>
    <h1>Daftar Produk - Makanan & Minuman</h1>
</body>

</html>
<?php /**PATH C:\laragon\www\Pemrograman-Web-Lanjut\Minggu-2\PWL-POS\resources\views/products/food-beverage.blade.php ENDPATH**/ ?>