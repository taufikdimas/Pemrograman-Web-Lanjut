<!DOCTYPE html>
<html>

<head>
    <title>Baby & Kid</title>
</head>

<body>
    <h1>Daftar Produk - Bayi & Anak</h1>
</body>

</html>
<?php /**PATH C:\laragon\www\Pemrograman-Web-Lanjut\Minggu-2\PWL-POS\resources\views/products/baby-kid.blade.php ENDPATH**/ ?>