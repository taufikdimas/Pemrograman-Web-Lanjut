<!DOCTYPE html>
<html>

<head>
    <title>Beauty & Health</title>
</head>

<body>
    <h1>Daftar Produk - Kecantikan & Kesehatan</h1>
</body>

</html>
