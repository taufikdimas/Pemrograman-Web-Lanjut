<!DOCTYPE html>
<html>

<head>
    <title>Food & Beverage</title>
</head>

<body>
    <h1>Daftar Produk - Makanan & Minuman</h1>
</body>

</html>
