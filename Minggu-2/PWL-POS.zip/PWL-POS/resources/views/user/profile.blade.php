<h1>User Profile</h1>
<p>User ID: {{ $id }}</p>
<p>User Name: {{ $name }}</p>
